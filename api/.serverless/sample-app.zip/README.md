This is a Eng<->Mon Eng->Eng dictionary dedicated for Mongolian sister and brothers.

To start the app, make sure you are in mango-mobile/api directory.

Then run, 
```npm run devStart```

To test if the build is successful, running:

```curl --location --request GET 'localhost:3000/dict?en=paper'```

from terminal would give the following result.

```{"en":"paper","mn":"tsaas"}%```

If any further concerns, reach out to **PIC** Tseso.

Have fun coding!

